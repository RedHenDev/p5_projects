let peas = [];   // Array of particles.
let mV;          // Mouse position vector.
let roi = 0;     // Rate of infection.
let covidStamp = 0;
let infDiff = roi;

// For turning on sticky attraction and
// infection dynamic.
let makeSticky = true;
let makeInfectious = true;

// Enum for mode a particle is in,
// to control different behaviours.
let pMode = {
  DEFAULT : 0,
  INFECTED: 1
}

function setup() {
  createCanvas(windowWidth,
               windowHeight);
  initObjs();
  mV = createVector(mouseX,mouseY);
  textAlign(CENTER,CENTER);
  strokeWeight(2);
}

function initObjs(){
  for (let i = 0; i < 50; i++){
    let temp = new Blook(true,i);
    peas.push(temp);
  }
  peas[13].mode = pMode.INFECTED;
}

function mousePressed(){
  //makeSticky = !makeSticky;
  makeInfectious = !makeInfectious;
  
  // Reset infection rate values.
  roi = 0;     // Rate of infection.
  infDiff = roi;
  
  if (makeInfectious) peas[13].mode =
    pMode.INFECTED;
}

function draw() {
  background(0,190,210,75);
  
  // Find position vector of mouse here, so only
  // once per update.
  mV.x = mouseX;
  mV.y = mouseY;
  
  for (let i = 0; i < peas.length; i++){
    peas[i].update();
    peas[i].render();
  }
  
  if (makeInfectious)
  displayProperties();
}

function displayProperties(){
  /* First, display infection rate.
  // Every second could be one day.
  So, rate of infection (ROI) is
  number of particles infected divided
  by how many days passed?
  */
 
  // Has another week passed?
  if (millis() - covidStamp > 7000){
  
  // Then count up how many infections.
  covidStamp = millis();
  let inf = 0;
  for (let p = 0; p < peas.length; p++){
    if (peas[p].mode === pMode.INFECTED) 
      inf++;
  }
  // Differnce between last number of infected
  // and present number.
  // ROI set to total present number.
  infDiff = inf - roi;
  roi = inf;
  }
  fill(255);
  noStroke();
  textSize(42);
  text("Rate = " + Math.round(infDiff), 142, 42);
    
}

class Blook{
 constructor(brownian, id){
   this.id = id;
   this.mode = pMode.DEFAULT;
   this.sticky = false;
   this.covid = false;
   this.pos = createVector();
   this.pos.x = random(width);
   this.pos.y = random(height);
   this.vel = createVector(0,0);
   this.vel.x = random(-1.5,1.5);
   this.vel.y = random(-1.5,1.5);
   this.acc = createVector();
   this.size = random(2,6);
   // How many seconds before random
   // acceleration change?
   this.brownian = brownian;
   this.tDC = random(1,4) * 1000;
   this.tDCstamp = 0;
 }
  
  render(){

    // Connecting lines.
    for (let p = this.id; p < peas.length; p++){
      if (peas[p] === this) continue;
      // stroke(map(this.pos.y,0,height,100,255),
      //        map(this.pos.x,0,width,100,255),
      //        map(this.pos.y,0,height,100,255),
      //        map(p5.Vector.sub(peas[p].pos,
      //   this.pos).mag(),0,width*0.25,255,0));
      let pDist = p5.Vector.sub(peas[p].pos,
        this.pos);
      stroke(255,map(pDist.mag(),50,100,255,0));
      
      // Check infection.
      if (this.covid){
      if (pDist.mag() < (this.size*5) &&
         peas[p].mode === pMode.INFECTED) this.mode = 
        pMode.INFECTED;
      if (pDist.mag() < (peas[p].size*5) &&
         this.mode === pMode.INFECTED) peas[p].mode = 
        pMode.INFECTED;
      }
      
      // Add mutual attraction force.
      if (this.sticky){
        if (pDist.mag() < this.size*5){
          this.acc.add(pDist.mult(0.0033));
          peas[p].acc.sub(pDist);
        }
      }
      
      line(this.pos.x,this.pos.y,
           peas[p].pos.x,peas[p].pos.y);
    }
    
    // Dot itself.
    //stroke(255,200);
    //fill(255,200);
    //circle(this.pos.x,this.pos.y,this.size);
    textSize(this.size*10);
    let pManifest = "🥶";
    let pInfect = "🥵";
    //"🤢";
    if (this.mode === pMode.DEFAULT)
      pManifest = "🥶";
      else if (this.mode === pMode.INFECTED)
        pManifest = pInfect;
    text(pManifest,this.pos.x,this.pos.y);
  }
  
  addRandomAcc(){
    this.acc.x += -2 + Math.random() * 4;
    this.acc.y += -2 + Math.random() * 4;
  }
  
  update(){
    
    // Avoid mouse.
    if (frameCount % 1 === 0 &&
        p5.Vector.dist(mV,this.pos) < 65){
     this.pos.sub(p5.Vector.
                  sub(mV,this.pos).
                  normalize().mult(8));
    }
    
    // Euler integration.
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    this.acc.x = 0;
    this.acc.y = 0;
    // Friction. Only if brownian motion on.
    if (this.brownian)
    this.vel.mult(0.99);
    
    // Screen-wrap.
    if (this.pos.x < 0) this.pos.x = width;
    if (this.pos.y < 0) this.pos.y = height;
    if (this.pos.x > width) this.pos.x = 0;
    if (this.pos.y > height) this.pos.y = 0;
    
    // Should I be sticky? Infectious?
    if (makeSticky) this.sticky = true;
    else this.sticky = false;
    if (makeInfectious) {
      this.covid = true;
    }
    else { this.covid = false;
          if (this.mode != pMode.DEFAULT)
             this.mode = pMode.DEFAULT;
         }

    // Timing events.
    if (!this.brownian)return;
    if (millis() - this.tDCstamp > this.tDC){
    this.tDCstamp = millis();
    this.addRandomAcc();
  } 
  }
}