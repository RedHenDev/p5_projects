let peas = [];
let mV;

function setup() {
  createCanvas(windowWidth,
               windowHeight);
  initObjs();
  mV = createVector(mouseX,mouseY);
}

function initObjs(){
  for (let i = 0; i < 55; i++){
    let temp = new Blook(false,i);
    peas.push(temp);
  }
}

function draw() {
  background(0,190,210);
  
  // Find position vector of mouse here, so only
  // once per update.
  mV.x = mouseX;
  mV.y = mouseY;
  
  for (let i = 0; i < peas.length; i++){
    peas[i].update();
    peas[i].render();
  }
}

class Blook{
 constructor(brownian, id){
   this.id = id;
   this.pos = createVector();
   this.pos.x = random(width);
   this.pos.y = random(height);
   this.vel = createVector(0,0);
   this.vel.x = random(-1.5,1.5);
   this.vel.y = random(-1.5,1.5);
   this.acc = createVector();
   this.size = random(2,6);
   // How many seconds before random
   // acceleration change?
   this.brownian = brownian;
   this.tDC = random(1,4) * 1000;
   this.tDCstamp = 0;
 }
  
  render(){

    // Connecting lines.
    for (let p = this.id; p < peas.length; p++){
      if (peas[p] === this) continue;
      // stroke(map(this.pos.y,0,height,100,255),
      //        map(this.pos.x,0,width,100,255),
      //        map(this.pos.y,0,height,100,255),
      //        map(p5.Vector.sub(peas[p].pos,
      //   this.pos).mag(),0,width*0.25,255,0));
      stroke(255,map(p5.Vector.sub(peas[p].pos,
        this.pos).mag(),0,180,255,0));
      line(this.pos.x,this.pos.y,
           peas[p].pos.x,peas[p].pos.y);
    }
    
    // Dot itself.
    stroke(255,200);
    fill(255,200);
    circle(this.pos.x,this.pos.y,this.size);
  }
  
  addRandomAcc(){
    this.acc.x += -2 + Math.random() * 4;
    this.acc.y += -2 + Math.random() * 4;
  }
  
  update(){
    
    // Avoid mouse.
    if (frameCount % 1 === 0 &&
        p5.Vector.dist(mV,this.pos) < 65){
     this.pos.sub(p5.Vector.
                  sub(mV,this.pos).
                  normalize().mult(8));
    }
    
    // Euler integration.
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    this.acc.x = 0;
    this.acc.y = 0;
    // Friction.
    //this.vel.mult(0.99);
    
    // Screen-wrap.
    if (this.pos.x < 0) this.pos.x = width;
    if (this.pos.y < 0) this.pos.y = height;
    if (this.pos.x > width) this.pos.x = 0;
    if (this.pos.y > height) this.pos.y = 0;
    
    

    // Timing events.
    if (!this.brownian)return;
    if (millis() - this.tDCstamp > this.tDC){
    this.tDCstamp = millis();
    this.addRandomAcc();
  } 
  }
}